#!/bin/bash
sudo rm -f /var/www/html/index.html
